package com.example.miaapplication;

public class FutureClass {
    private String dayFuture;
    private String imgLink;
    private String statusFuture;
    private int highestTemp;
    private int lowestTemp;

    public FutureClass (String dayFuture, String imgLink, String statusFuture, int highestTemp, int lowestTemp){
        this.dayFuture=dayFuture;
        this.imgLink=imgLink;
        this.statusFuture=statusFuture;
        this.highestTemp=highestTemp;
        this.lowestTemp=lowestTemp;
    }

    public String getDayFuture() {
        return dayFuture;
    }
    public void setDayFuture(String dayFuture){
        this.dayFuture=dayFuture;
    }
    public String getImgLink(){
        return imgLink;
    }
    public void setImgLink(String imgLink) {
        this.imgLink = imgLink;
    }

    public String getStatusFuture(){
        return statusFuture;
    }
    public void setStatusFuture(String statusFuture){
        this.statusFuture=statusFuture;
    }
    public int getHighestTemp(){
        return highestTemp;
    }

    public void setHighestTemp(int highestTemp) {
        this.highestTemp = highestTemp;
    }

    public int getLowestTemp(){
        return lowestTemp;
    }

    public void setLowestTemp(int lowestTemp) {
        this.lowestTemp = lowestTemp;
    }
}
