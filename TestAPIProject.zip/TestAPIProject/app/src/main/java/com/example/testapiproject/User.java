package com.example.testapiproject;

public class User {
    public String login;
    public int id;
    public String avatar_url;
}
