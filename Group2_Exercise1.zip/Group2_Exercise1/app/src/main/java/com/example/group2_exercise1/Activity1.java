package com.example.group2_exercise1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity1 extends AppCompatActivity {
    private Button btn1;
    public Button btnCall;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);
        Log.v("API CALL: ", "Activities1: onCreate");

        Intent intent = getIntent();
        if (intent != null) {
            String receivedData = intent.getStringExtra("key");

            // Hiển thị dữ liệu trong giao diện
            TextView textView = findViewById(R.id.textView);
            textView.setText(receivedData);
        }

        btnCall = findViewById(R.id.btn_act2);
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent render2 = new Intent(Intent.ACTION_DIAL);
                startActivity(render2);
            }
        });

        btn1 = findViewById(R.id.btn_act1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent render = new Intent(Activity1.this, Activity2.class);
                startActivity(render);
            }
        });

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v("API CALL: ", "Activities1: onDestroy");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v("API CALL: ", "Activities1: onStart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.v("API CALL: ", "Activities1: onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.v("API CALL: ", "Activities1: onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.v("API CALL: ", "Activities1: onStop");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v("API CALL: ", "Activities1: onRestart");
    }
}