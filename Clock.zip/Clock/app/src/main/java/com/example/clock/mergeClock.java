package com.example.clock;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class mergeClock extends AppCompatActivity {
    private ImageView playPauseButton;
    private ImageView restartButton;
    private ProgressBar progressBar;
    private TextView countdownText;
    private CountDownTimer countDownTimer;
    private boolean isTimerRunning = false;

    long totalTimeInMillis = 1 * 30 * 1000;
    long timeLeftInMillis = totalTimeInMillis;
    public ImageView img_X ;
    public ImageView img_mini ;
    public ImageView img_zoom ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.merge);

        playPauseButton = findViewById(R.id.playPauseButton);
        restartButton = findViewById(R.id.restartButton);
        countdownText = findViewById(R.id.countdownText);
        progressBar = findViewById(R.id.progressBar);
        img_X = findViewById(R.id.buttonExit);
        img_mini = findViewById(R.id.buttonMinimize);
        img_zoom = findViewById(R.id.buttonZoom);
    }
    public void startPauseTimer(View view) {
        if (isTimerRunning) {
            playPauseButton.setImageResource(R.drawable.baseline_play_circle_24);
            countDownTimer.cancel();
        } else {
            playPauseButton.setImageResource(R.drawable.baseline_pause_circle_24);
            countDownTimer = new CountDownTimer(totalTimeInMillis, 1000) {
                public void onTick(long millisUntilFinished) {
                    updateCountdownText(millisUntilFinished);
                }
                public void onFinish() {
                    updateCountdownText(0);
                }
            }.start();
        }
        isTimerRunning = !isTimerRunning;
    }
    public void restartTimer(View view) {
        playPauseButton.setImageResource(R.drawable.baseline_play_circle_24);
        if (isTimerRunning) {
            countDownTimer.cancel();
            isTimerRunning = false;
        }

        timeLeftInMillis = totalTimeInMillis;
        updateCountdownText(timeLeftInMillis);
        progressBar.setProgress(100);
    }
    private void updateCountdownText(long millisUntilFinished) {
        long seconds = millisUntilFinished / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        seconds = seconds % 60;
        minutes = minutes % 60;

        String countdownTextStr = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        countdownText.setText(countdownTextStr);

        // Cập nhật giá trị của ProgressBar
        int progress = (int) (millisUntilFinished * 100 / totalTimeInMillis);
        progressBar.setProgress(progress);
    }

    public  void exitApp(View view)
    {
        setRedBackgroundColor(1);
        finish();
    }
    public void minimizeApp(View view){
        setRedBackgroundColor(2);
        moveTaskToBack(true);// Tạm tắt ứng dụng xuống nền
    }
    public void zoomApp(View view) {
        setRedBackgroundColor(3);
        Toast.makeText(this, "Phóng to hoặc thu nhỏ ứng dụng", Toast.LENGTH_SHORT).show();
    }

    private void changeBackgroundColor_X(int color) {
        img_X.setBackgroundColor(color);
    }
    private void changeBackgroundColor_Mini(int color) {
        img_mini.setBackgroundColor(color);
    }
    private void changeBackgroundColor_Zoom(int color) {
        img_zoom.setBackgroundColor(color);
    }

    private void setRedBackgroundColor(int number) {
        if (number==1){
            int redColor = getResources().getColor(R.color.red); // Lấy màu đỏ từ tệp màu tài nguyên
            img_X.setBackgroundColor(redColor);
        }
        if (number==2){
            int blueColor = getResources().getColor(R.color.blue); // Lấy màu đỏ từ tệp màu tài nguyên
            img_mini.setBackgroundColor(blueColor);
        }
        if (number==3){
            int blueColor = getResources().getColor(R.color.blue); // Lấy màu đỏ từ tệp màu tài nguyên
            img_zoom.setBackgroundColor(blueColor);
        }

    }

}