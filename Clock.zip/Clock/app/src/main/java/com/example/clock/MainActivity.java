package com.example.clock;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private ImageView playPauseButton;
    private ImageView restartButton;
    private TextView countdownText;
    private CountDownTimer countDownTimer;
    private boolean isTimerRunning = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playPauseButton = findViewById(R.id.playPauseButton);
        restartButton = findViewById(R.id.restartButton);
        countdownText = findViewById(R.id.countdownText);
    }
    public void startPauseTimer(View view) {
        if (isTimerRunning) {
            // Ngừng đồng hồ đếm ngược
            playPauseButton.setImageResource(R.drawable.baseline_play_circle_24);
            countDownTimer.cancel();
//            playPauseButton.setImageDrawable();
        } else {
            // Bắt đầu đồng hồ đếm ngược (ví dụ: 5 phút)
            playPauseButton.setImageResource(R.drawable.baseline_pause_circle_24);
            long totalTimeInMillis = 5 * 60 * 1000;
            countDownTimer = new CountDownTimer(totalTimeInMillis, 1000) {
                public void onTick(long millisUntilFinished) {
                    updateCountdownText(millisUntilFinished);
                }

                public void onFinish() {
                    updateCountdownText(0);
                }
            }.start();
//            playPauseButton.setText("Pause");
        }
        isTimerRunning = !isTimerRunning;
    }
    public void restartTimer(View view) {
        playPauseButton.setImageResource(R.drawable.baseline_play_circle_24);
        if (isTimerRunning) {

            countDownTimer.cancel();
            isTimerRunning = false;
//            playPauseButton.setText("Play");
        }
        updateCountdownText(0);
    }

    private void updateCountdownText(long millisUntilFinished) {
        long seconds = millisUntilFinished / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        seconds = seconds % 60;
        minutes = minutes % 60;

        String countdownTextStr = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        countdownText.setText(countdownTextStr);
    }

    public  void exitApp(View view)
    {
        finish();
    }
    public void minimizeApp(View view){
        moveTaskToBack(true);// Tạm tắt ứng dụng xuống nền
    }
    public void zoomApp(View view) {
        // Thực hiện phóng to hoặc thu nhỏ ứng dụng theo ý muốn
        // (Đây bạn có thể thêm mã để thực hiện chức năng phóng to thu nhỏ)
        Toast.makeText(this, "Phóng to hoặc thu nhỏ ứng dụng", Toast.LENGTH_SHORT).show();
    }


}