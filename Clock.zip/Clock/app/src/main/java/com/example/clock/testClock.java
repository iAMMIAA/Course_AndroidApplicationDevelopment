package com.example.clock;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class testClock extends AppCompatActivity {
    private TextView timerTextView;
    private ProgressBar progressBar;
    private CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        timerTextView = findViewById(R.id.timerTextView);
        progressBar = findViewById(R.id.progressBar);

        // Thời gian đếm ngược là 10 giây (10000 milliseconds)
        long countdownTime = 20000;

        countDownTimer = new CountDownTimer(countdownTime, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Cập nhật thời gian còn lại
                long secondsRemaining = millisUntilFinished / 1000;
                timerTextView.setText(String.valueOf(secondsRemaining));

                // Cập nhật giá trị của ProgressBar
                int progress = (int) (millisUntilFinished * 100 / countdownTime);
                progressBar.setProgress(progress);
            }

            @Override
            public void onFinish() {
                // Đã kết thúc đếm ngược
                timerTextView.setText("Done");
            }
        };

        // Bắt đầu đếm ngược
        countDownTimer.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Hủy đếm ngược khi Activity hoặc Fragment bị hủy
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}
