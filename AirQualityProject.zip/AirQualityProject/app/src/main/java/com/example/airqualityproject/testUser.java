package com.example.airqualityproject;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
public class testUser extends  AppCompatActivity{
    private TextView txtFullName, txtAge, txtLocation;
    private EditText edtFullName, edtAge, edtLocation;
    private Button btnSave;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_user);

        txtFullName = findViewById(R.id.txtFullName);
        txtAge = findViewById(R.id.txtAge);
        txtLocation = findViewById(R.id.txtLocation);
        edtFullName = findViewById(R.id.edtFullName);
        edtAge = findViewById(R.id.edtAge);
        edtLocation = findViewById(R.id.edtLocation);
        btnSave = findViewById(R.id.btnSave);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        userId = getIntent().getStringExtra("userId");

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName = edtFullName.getText().toString();
                String age = edtAge.getText().toString();
                String location = edtLocation.getText().toString();

                updateUserInformation(fullName, age, location);
            }
        });

        getUserInformation();
    }

    private void getUserInformation() {
        DatabaseReference userRef = mDatabase.child("users").child(userId);
        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    User user = dataSnapshot.getValue(User.class);
                    if (user != null) {
                        txtFullName.setText(user.getFullName());
                        txtAge.setText(user.getAge());
                        txtLocation.setText(user.getLocation());

                        edtFullName.setText(user.getFullName());
                        edtAge.setText(user.getAge());
                        edtLocation.setText(user.getLocation());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ProfileActivity.this, "Lỗi khi truy vấn dữ liệu", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateUserInformation(String fullName, String age, String location) {
        DatabaseReference userRef = mDatabase.child("users").child(userId);
        User updatedUser = new User(fullName, age, location);
        userRef.setValue(updatedUser)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(ProfileActivity.this, "Cập nhật thông tin thành công", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ProfileActivity.this, "Cập nhật thông tin thất bại", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
