package com.example.airqualityproject;

public class Class_User {
    String fullName;
    String age;
    String email;
    String numberPhone;
    public Class_User(String fullName, String age, String email, String numberPhone) {
        this.fullName = fullName;
        this.age = age;
        this.email = email;
        this.numberPhone = numberPhone;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getNumberPhone() {
        return numberPhone;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNumberPhone(String numberPhone) {
        this.numberPhone = numberPhone;
    }
}
