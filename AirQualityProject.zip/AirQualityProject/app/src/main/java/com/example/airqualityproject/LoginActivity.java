package com.example.airqualityproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {
    private ImageView btnComebackAct;
    private EditText et_username_act, et_pass_act, et_email_act;
    private Button btn_login_act;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth = FirebaseAuth.getInstance();

        btnComebackAct = findViewById(R.id.btn_comeback_log);
//        et_username_act = findViewById(R.id.act_et_username);
        et_pass_act = findViewById(R.id.act_et_pass);
        et_email_act = findViewById(R.id.act_et_username);
        btn_login_act = findViewById(R.id.act_btn_login);

        btnComebackAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent renderHome = new Intent(LoginActivity.this, IntroActivity.class);
                startActivity(renderHome);
            }
        });
        btn_login_act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str_password = et_pass_act.getText().toString();
                String str_email = et_email_act.getText().toString();

                if (str_password.isEmpty() || str_email.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter the information again.", Toast.LENGTH_SHORT).show();
                } else {
                    firebaseAuth.signInWithEmailAndPassword(str_email, str_password)
                            .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(LoginActivity.this, "Successfully logged in!", Toast.LENGTH_SHORT).show();
                                        FirebaseUser user = firebaseAuth.getCurrentUser();
                                        Intent renderHome = new Intent(LoginActivity.this, MainActivity.class);
                                        startActivity(renderHome);
                                    } else {
                                        Toast.makeText(LoginActivity.this, "Failed to log in!", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });
    }

}
