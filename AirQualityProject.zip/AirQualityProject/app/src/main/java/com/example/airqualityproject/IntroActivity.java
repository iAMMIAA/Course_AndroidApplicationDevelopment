package com.example.airqualityproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class IntroActivity extends AppCompatActivity {
    private Button btnLoginAct;
    private Button btnRegisterAct;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        btnLoginAct = findViewById(R.id.btn_login_intro);
        btnRegisterAct = findViewById(R.id.btn_register_intro);

        btnRegisterAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent renderRegisterForm = new Intent(IntroActivity.this, RegisterActivity.class);
                startActivity(renderRegisterForm);
            }
        });
        btnLoginAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent renderLoginForm = new Intent(IntroActivity.this, LoginActivity.class);
                startActivity(renderLoginForm);
            }
        });

    }
}

