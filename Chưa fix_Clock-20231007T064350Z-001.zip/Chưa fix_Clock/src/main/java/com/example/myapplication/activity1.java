package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
public class activity1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1);
        // Ghi log cho hàm onCreate
        Log.d("Activity1", "onCreate");
        findViewById(R.id.btn_to_activity2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mở Activity2
                startActivity(new Intent(activity1.this, activity2.class));
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();

        // Ghi log trạng thái của Activity1
        Log.d("Activity1", "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Ghi log trạng thái của Activity1
        Log.d("Activity1", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Ghi log trạng thái của Activity1
        Log.d("Activity1", "onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Ghi log trạng thái của Activity1
        Log.d("Activity1", "onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Ghi log trạng thái của Activity1
        Log.d("Activity1", "onDestroy()");
    }
}
