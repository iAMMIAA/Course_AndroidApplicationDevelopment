package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class clock extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView textView;
    private ImageButton buttonPlay, buttonReset;
    private CountDownTimer countDownTimer;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clock);

        progressBar = findViewById(R.id.progressBar);
        textView = findViewById(R.id.textView);
        buttonPlay = findViewById(R.id.btn_play);
        buttonReset = findViewById(R.id.btn_reset);

        progressBar.setMax(180);

        buttonPlay.setOnClickListener(v -> {
            countDownTimer = new CountDownTimer(180000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    progressBar.setProgress((int) (millisUntilFinished / 1000));
                    textView.setText(String.format("%02d:%02d:%02d",
                            (millisUntilFinished / 3600000),
                            (millisUntilFinished / 60000) % 60,
                            (millisUntilFinished / 1000) % 60));
                }

                @Override
                public void onFinish() {
                    textView.setText("Hết giờ!");
                }
            };

            countDownTimer.start();
        });

        buttonReset.setOnClickListener(v -> {
            if (countDownTimer != null) {
                countDownTimer.cancel();
            }

            progressBar.setProgress(0);
            textView.setText("00:03:00");
        });


    }
}
