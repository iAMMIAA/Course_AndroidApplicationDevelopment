package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class activity2 extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
        // Ghi log cho hàm onCreate
        Log.d("Activity2", "onCreate");
        findViewById(R.id.btn_to_activity1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mở Activity1
                startActivity(new Intent(activity2.this, activity1.class));
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();

        // Ghi log trạng thái của Activity2
        Log.d("Activity2", "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Ghi log trạng thái của Activity2
        Log.d("Activity2", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Ghi log trạng thái của Activity2
        Log.d("Activity2", "onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Ghi log trạng thái của Activity2
        Log.d("Activity2", "onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Ghi log trạng thái của Activity2
        Log.d("Activity2", "onDestroy()");
    }
}
