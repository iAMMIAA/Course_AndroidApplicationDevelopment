package com.example.testapiproject_1component;
import com.squareup.moshi.Json;
import com.squareup.moshi.JsonClass;

@JsonClass(generateAdapter = true)

public class WeatherInfo {
    @Json(name = "city")
    private String city;

    @Json(name = "state")
    private String state;

    @Json(name = "country")
    private String country;

    @Json(name = "current")
    private CurrentWeather current;

    public CurrentWeather getCurrent() {
        return current;
    }


    // Các getter và setter cho các thuộc tính này
}
