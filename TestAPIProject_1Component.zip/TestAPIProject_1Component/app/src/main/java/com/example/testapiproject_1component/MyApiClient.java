package com.example.testapiproject_1component;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MyApiClient {
    private OkHttpClient client = new OkHttpClient();
    public String fetchDataFromApi(String apiUrl) throws IOException{
        Request request = new Request.Builder()
                .url(apiUrl)
                .build();

        try(Response response = client.newCall(request).execute()) {
            if(!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            return response.body().string();
        }
    }

}
