package com.example.testapiproject_1component;
import com.squareup.moshi.Json;
import com.squareup.moshi.JsonClass;

@JsonClass(generateAdapter = true)
public class WeatherDetails {
    @Json(name = "ts")
    private String timestamp;

    @Json(name = "tp")
    private int temperature;

    @Json(name = "pr")
    private int pressure;

    public int getPressure() {
        return pressure;
    }

    public int getTemperature() {
        return temperature;
    }

    // Các getter và setter cho các thuộc tính này
}