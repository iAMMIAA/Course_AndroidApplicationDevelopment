package com.example.testapiproject_1component;
import com.squareup.moshi.Json;
import com.squareup.moshi.JsonClass;
@JsonClass(generateAdapter = true)
public class CurrentWeather {
    @Json(name = "weather")
    private WeatherDetails weatherDetails;

    public WeatherDetails getWeatherDetails() {
        return weatherDetails;
    }

    // Các getter và setter cho các thuộc tính này
}