package com.example.testapiproject_1component;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import java.io.IOException;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.adapters.Rfc3339DateJsonAdapter;

public class MainActivity extends AppCompatActivity {
    private TextView resultTextView;
    private String apiUrl = "https://api.airvisual.com/v2/nearest_city?key=95c6db34-b6c1-4f47-910d-2fcef6c521da";

//    private String apiUrl = "http://127.0.0.1:8000/api/listUser/";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTextView = findViewById(R.id.resultTextView);

        //Goi API bat dong bo
        new FetchDataAsyncTask().execute();
    }

    private class FetchDataAsyncTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            try{
                MyApiClient apiClient = new MyApiClient();
                return apiClient.fetchDataFromApi(apiUrl);
            } catch (IOException e){
                e.printStackTrace();
                return null;
            }
        }
        protected void onPostExecute(String result) {
            try {
                if (result != null) {
                    Moshi moshi = new Moshi.Builder()
                            .add(Date.class, new Rfc3339DateJsonAdapter())
                            .build();

                    JsonAdapter<WeatherData> jsonAdapter = moshi.adapter(WeatherData.class);
                    WeatherData weatherData = jsonAdapter.fromJson(result);

                    if (weatherData != null && weatherData.getData() != null && weatherData.getData().getCurrent() != null) {
                        WeatherDetails weatherDetails = weatherData.getData().getCurrent().getWeatherDetails();
                        if (weatherDetails != null) {
                            String weatherInfoText = "Temperature: " + weatherDetails.getTemperature() + "°C\nPressure: " + weatherDetails.getPressure() + " hPa";
                            resultTextView.setText(weatherInfoText);
                        } else {
                            resultTextView.setText("Weather data not available.");
                        }
                    } else {
                        resultTextView.setText("Weather data not available.");
                    }
                } else {
                    resultTextView.setText("Failed to fetch data from API.");
                }
            } catch (IOException e) {
                e.printStackTrace();
                resultTextView.setText("Error while parsing JSON.");
            }
        }
    }
}


