package com.example.testapiproject_1component;
import com.squareup.moshi.Json;
import com.squareup.moshi.JsonClass;

@JsonClass(generateAdapter = true)
public class WeatherData {
    @Json(name = "status")
    private String status;

    @Json(name = "data")
    private WeatherInfo data;

    public WeatherInfo getData() {
        return data;
    }


    // Các getter và setter cho các thuộc tính này
}
