package com.example.relativelayout;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.widget.RelativeLayout;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout mainLayout;
    private Drawable[] backgrounds;
    private int currentBackgroundIndex = 0;
    private Handler handler;
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainLayout = findViewById(R.id.main_layout);
        backgrounds = new Drawable[] {
                getResources().getDrawable(R.drawable.background_1),
                getResources().getDrawable(R.drawable.background_2),
                getResources().getDrawable(R.drawable.background_3)
        };
        handler = new Handler();
        timer = new Timer();
        timer.schedule(new BackgroundTask(), 0, 3000);
    }
    private class BackgroundTask extends TimerTask {
        @Override
        public void run() {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    changeBackground();
                }
            });
        }
    }
    private void changeBackground() {
        mainLayout.setBackground(backgrounds[currentBackgroundIndex]);
        currentBackgroundIndex++;
        if (currentBackgroundIndex >= backgrounds.length) {
            currentBackgroundIndex = 0;
        }
    }
}